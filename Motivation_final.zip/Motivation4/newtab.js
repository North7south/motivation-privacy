let dob = null;
let lifespan = 80;

function calcAgeExact(now, birth) {
  const msPerYear = 365.25 * 24 * 60 * 60 * 1000;
  return (now - birth) / msPerYear;
}

function update() {
  if (!dob) return;
  const now = new Date();

  const ageExact = calcAgeExact(now, dob);
  const ageInt = Math.floor(ageExact);
  const ageDec = (ageExact - ageInt).toFixed(6).slice(1);
  document.getElementById('age-int').textContent = ageInt;
  document.getElementById('age-dec').textContent = ageDec;

  const yStart = new Date(now.getFullYear(), 0, 1);
  const yEnd = new Date(now.getFullYear() + 1, 0, 1);
  const yPct = ((now - yStart) / (yEnd - yStart) * 100);
  document.getElementById('yr-bar').style.width = yPct.toFixed(2) + '%';
  document.getElementById('yr-pct').textContent = yPct.toFixed(1) + '%';
  document.getElementById('yr-label').textContent = now.getFullYear();

  const totalMs = lifespan * 365.25 * 86400000;
  const lPct = Math.min(((now - dob) / totalMs * 100), 100);
  document.getElementById('life-bar').style.width = lPct.toFixed(2) + '%';
  document.getElementById('life-pct').textContent = lPct.toFixed(1) + '%';
}

function showMain(birth, ls) {
  dob = birth;
  lifespan = ls;
  chrome.storage.local.set({ dob: birth.toISOString(), lifespan: ls });
  document.getElementById('setup').style.display = 'none';
  document.getElementById('main').style.display = 'flex';
  update();
}

document.getElementById('save-btn').addEventListener('click', function () {
  const val = document.getElementById('dob-input').value;
  const ls = parseInt(document.getElementById('life-input').value) || 80;
  if (!val) return;
  const parts = val.split('-');
  showMain(new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2])), ls);
});

document.getElementById('reset-btn').addEventListener('click', function () {
  chrome.storage.local.remove(['dob', 'lifespan']);
  document.getElementById('main').style.display = 'none';
  document.getElementById('setup').style.display = 'flex';
  dob = null;
});

chrome.storage.local.get(['dob', 'lifespan'], function(result) {
  if (result.dob) {
    showMain(new Date(result.dob), parseInt(result.lifespan) || 80);
  }
});

setInterval(update, 50);
